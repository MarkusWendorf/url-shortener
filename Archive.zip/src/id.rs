use rand::Rng;

const ID_LENGTH: usize = 8;
const ALPHABET: &[char] = &[
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
    'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
];

pub fn generate_id() -> String {
    let mut random = rand::thread_rng();

    (0..ID_LENGTH)
        .map(|_| ALPHABET[random.gen_range(0..ALPHABET.len())])
        .collect()
}
